import streamlit as st
import subprocess
import greeting1
import greeting2

def get_page_param():
    # クエリパラメーターを辞書形式で取得できる
    query_params = st.experimental_get_query_params()
    if 'page' in query_params:
        # 各パラメーターの値はリストに格納されている
        return query_params['page'][0]
    else:
        return None

def main():
    pages = {
        "App1": greeting1,
        "App2": greeting2
    }

    page_names = list(pages.keys())
    
    page_name = get_page_param()
    st.write("test")
    st.write(page_name)
    # 現時点では、 session_state を指定しないと挙動がおかしくなる
    # くわしくは https://github.com/streamlit/streamlit/issues/3635
    if page_name in pages and 'page' not in st.session_state:
        st.session_state['page'] = page_name
    
    with st.sidebar:
        if page_name is None:
            index = 0
        else:
            index = page_names.index(page_name)
        # ローカル環境と Streamlit Cloud で挙動が異なる。ローカル環境では index に 0 を指定する
        page = st.selectbox('select page', page_names, index=index, key='page')
        st.experimental_set_query_params(page=page)
        
    pages[page].app()

if __name__ == '__main__':
    main()
