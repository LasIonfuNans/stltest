import streamlit as st

def app():
    st.title('こんにちは, 世界！')
    st.write('ねこはかわいい')
